import React from 'react'
function Home() {
  return (
    <div>
      <h1 align ="center" >WELCOME TO THE FOOD DELIVARY APP</h1>
      <br></br>
      <center><img src="images.png"/></center>
    </div>
  )
}

export default Home